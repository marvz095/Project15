
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct node {
	string job, fName, IName, IDHold, depIDHold, bDay, sex, streetnum, street, city, state,
		zip, phone, email;
	node *next;
};

class linkedList
{
private:
	node *head, *tail;
public:
	linkedList() {
		head = NULL; tail = NULL;
	}

	void addNode(string job, string fName, string IName, string IDHold, string depIDHold, string bDay, string sex, string streetnum, string street, string city, string state, string zip, string phone, string email) {
		node *temp = new node;
		temp->job = job;
		temp->fName = fName;
		temp->IName = IName;
		temp->IDHold = IDHold;
		temp->depIDHold = depIDHold;
		temp->bDay = bDay;
		temp->sex = sex;
		temp->streetnum = streetnum;
		temp->street = street;
		temp->city = city;
		temp->state = state;
		temp->zip = zip;
		temp->phone = phone;
		temp->email = email;
		if (head == NULL) {
			head = temp;
			tail = temp;
			temp = NULL;
		}
		else {
			tail->next = temp;
			tail = temp;
		}
	}
};
